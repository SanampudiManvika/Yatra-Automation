package Trip_Package_Automation;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Set;
 
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class YatraTicketBooking {
		 
			public static void main(String[] args) throws InterruptedException, IOException {
						// TODO Auto-generated method stub
						WebDriver driver = new ChromeDriver();
						driver.get("https://www.yatra.com/");
						driver.manage().window().maximize();
						// Thread.sleep(3000);
						driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
						// to close the sign in box
						driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div[1]/div[2]/div/section[2]/span/img")).click();
		 
						// scroll to view all offers
						JavascriptExecutor js = (JavascriptExecutor) driver;
						WebElement offers = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div[1]/div/div[2]/div[2]/div"));
						js.executeScript("arguments[0].scrollIntoView()", offers);
						// Thread.sleep(3000);
						driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div[1]/div/div[2]/div[2]/div")).click();
		 
						// click the offers link
//								WebElement offers1=driver.findElement(By.xpath("//*[@id=\"themeSnipe\"]/div[1]/div[3]/div[2]/div/ul/li[4]/a"));
//								offers1.click();
		 
						// the file has showing the previous page title so we need to return the current
						// page title
						Set<String> windowIds = driver.getWindowHandles();
						for (String windowid : windowIds) {
							driver.switchTo().window(windowid);
							String actualTitle = driver.getTitle();
							String expectedTitle = "Domestic Flights Offers | Deals on Domestic Flight Booking | Yatra.com";
							// System.out.println(actualTitle);
							if (actualTitle.equals(expectedTitle)) {
								System.out.println("Title matched: " + actualTitle);
								// Taking screenshot
								File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
								FileUtils.copyFile(screenshot, new File("title_matched_screenshot.png"));
								System.out.println("Screenshot saved as title_matched_screenshot.png");
							}
		 
						}
		 
						// Click on Holidays
						driver.findElement(By.linkText("Holidays")).click();
						// Thread.sleep(5000);
		 
						// Get holiday package names and prices
//						WebElement vd = driver.findElement(By.xpath("(//span[text()='View Details'])[7]"));
//						vd.click();
		 
						// Get all window handles
						Set<String> allWindows = driver.getWindowHandles();
		           
						clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 7);
						printPrice(driver, "Holy Trails Of Do Dham - Standard Package Holiday Package, Guptkashi | Yatra.com", "Holy Trails Of Do Dham - Standard Package");
						
						clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 6);
						printPrice(driver, "Guwahati 2 N With Kamakhya Devi Temple Holiday Package, Guwahati | Yatra.com","Guwahati 2 N With Kamakhya Devi Temple");
						
						clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 11);
						printPrice(driver, "Bhutan Royal Trail Holiday Package, Paro | Yatra.com","Bhutan Royal Trail");
						
						clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 8);
						printPrice(driver,"Three Capitals Of Korea ( Small Group Tour ) - Autumn Special Holiday Package, Seoul | Yatra.com", "Three Capitals Of Korea ( Small Group Tour ) - Autumn Special");
				// TODO Auto-generated method stub
						
						clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 4);
						printPrice(driver,"Divine Ayodhya Yatra Holiday Package, Ayodhya | Yatra.com", "Divine Ayodhya Yatra");
					}
					
					
					// method
					public static void clickViewDetails(WebDriver driver, String expectedTitle, int viewDetailsIndex) {
					    Set<String> allWindows = driver.getWindowHandles();
		 
					    for (String windowId : allWindows) {
					        driver.switchTo().window(windowId);
					        if (driver.getTitle().equals(expectedTitle)) {
					            driver.findElement(By.xpath("(//span[text()='View Details'])[" + viewDetailsIndex + "]")).click();
					            break;
					        }
					    }
					}
				//method end
		 
					public static  void printPrice(WebDriver driver,String title,String packagenames) {
						Set<String> allWindows = driver.getWindowHandles();
		 
						for (String windowId : allWindows) {
							driver.switchTo().window(windowId);
							if (driver.getTitle()
									.equals(title)) {
								String price = driver
										.findElement(By.xpath("//span[text()='Starting From']/..//span[contains(@class,'price ')]"))
										.getText();
								String packagename = driver
										.findElement(By.xpath("(//h2[text()='"+packagenames+"'])[2]"))
										.getText();
								System.out.println(packagename + "   " + price);
								break;
		 
							}
						}
					
						
					}
			
		 
			}
		 
		 
		