package com.GenericUtilities;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 import java.util.*;
public class GenericUtilities {
	// method
	public static void clickViewDetails(WebDriver driver, String expectedTitle, int viewDetailsIndex) {
			    Set<String> allWindows = driver.getWindowHandles();

			    for (String windowId : allWindows) {
			        driver.switchTo().window(windowId);
			        if (driver.getTitle().equals(expectedTitle)) {
			            driver.findElement(By.xpath("(//span[text()='View Details'])[" + viewDetailsIndex + "]")).click();
			            break;
			        }
			    }
			}
		//method end	
	public static  void printPrice(WebDriver driver,String title,String packagenames) {
		Set<String> allWindows = driver.getWindowHandles();

		for (String windowId : allWindows) {
			driver.switchTo().window(windowId);
			if (driver.getTitle()
					.equals(title)) {
				String price = driver
						.findElement(By.xpath("//span[text()='Starting From']/..//span[contains(@class,'price ')]"))
						.getText();
				String packagename = driver
						.findElement(By.xpath("(//h2[text()='"+packagenames+"'])[2]"))
						.getText();
				System.out.println(packagename + "   " + price);
				break;

			}
		}	
	}
}

