package com.TestScripts;

import com.Base.BaseClass;
import com.GenericUtilities.GenericUtilities;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Set;
	

	public class YatraTicketBookingTest extends BaseClass {

	    @Test(priority = 1)
	    public void closeSignInPopup() {
	        driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div[1]/div[2]/div/section[2]/span/img")).click();
	    }

	    @Test(priority = 2)
	    public void openOffersPage() {
	        WebElement offers = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div[1]/div/div[2]/div[2]/div"));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView()", offers);
	        offers.click();
	    }

	    @Test(priority = 3)/*
	    public void validateTitleAndScreenshot() throws IOException {
	        Set<String> windowIds = driver.getWindowHandles();
	        for (String windowid : windowIds) {
	            driver.switchTo().window(windowid);
	            String actualTitle = driver.getTitle();
	            String expectedTitle = "Domestic Flights Offers | Deals on Domestic Flight Booking | Yatra.com";
	            if (actualTitle.equals(expectedTitle)) {
	                File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	                FileUtils.copyFile(screenshot, new File("title_matched_screenshot.png"));
	                System.out.println("Screenshot saved.");
	                break;
	            }
	        }
	    }
*/
	    public void validateTitleAndScreenshot() {
	        try {
	            Set<String> windowIds = driver.getWindowHandles();
	            boolean titleMatched = false;

	            for (String windowId : windowIds) {
	                driver.switchTo().window(windowId);
	                String actualTitle = driver.getTitle();
	                String expectedTitle = "Domestic Flights Offers | Deals on Domestic Flight Booking | Yatra.com";

	                if (actualTitle.equals(expectedTitle)) {
	                    try {
	                        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	                        FileUtils.copyFile(screenshot, new File("title_matched_screenshot.png"));
	                        System.out.println("Screenshot saved as title_matched_screenshot.png");
	                    } catch (IOException e) {
	                        System.err.println("Failed to save screenshot: " + e.getMessage());
	                    }
	                    titleMatched = true;
	                    break;
	                }
	            }

	            if (!titleMatched) {
	                System.err.println("Expected title not found in any window.");
	            }

	        } catch (Exception e) {
	            System.err.println("Error during title validation and screenshot capture: " + e.getMessage());
	            e.printStackTrace();
	        }
	    }

	    @Test(priority = 4)
	    public void clickHolidayLink() {
	        driver.findElement(By.linkText("Holidays")).click();
	    }

	    @Test(priority = 5)
	    public void fetchHolidayPackages() {
	        GenericUtilities.clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 7);
	        GenericUtilities.printPrice(driver, "Holy Trails Of Do Dham - Standard Package Holiday Package, Guptkashi | Yatra.com", "Holy Trails Of Do Dham - Standard Package");

	        GenericUtilities.clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 6);
	        GenericUtilities.printPrice(driver, "Guwahati 2 N With Kamakhya Devi Temple Holiday Package, Guwahati | Yatra.com", "Guwahati 2 N With Kamakhya Devi Temple");

	        GenericUtilities.clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 11);
	        GenericUtilities.printPrice(driver, "Bhutan Royal Trail Holiday Package, Paro | Yatra.com", "Bhutan Royal Trail");

	        GenericUtilities.clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 8);
	        GenericUtilities.printPrice(driver, "Three Capitals Of Korea ( Small Group Tour ) - Autumn Special Holiday Package, Seoul | Yatra.com", "Three Capitals Of Korea ( Small Group Tour ) - Autumn Special");

	        GenericUtilities.clickViewDetails(driver, "Offers on domestic and international holidays | Yatra.com", 4);
	        GenericUtilities.printPrice(driver, "Divine Ayodhya Yatra Holiday Package, Ayodhya | Yatra.com", "Divine Ayodhya Yatra");
	    }
	}


